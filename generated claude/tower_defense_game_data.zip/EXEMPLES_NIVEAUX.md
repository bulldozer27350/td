# 🎮 Exemples Détaillés de Niveaux

## 📌 Niveau 1 - Tutorial Facile

### Configuration
- **Map** : 12×12
- **Budget** : 300$
- **Vies** : 15
- **Chemin** : Simple en L

### Vagues
1. **Vague 1** (tick 10) : 15 Gobelins
   - HP : 50 chaque
   - Speed : 2.0
   - Bounty : 3$ × 15 = 45$

2. **Vague 2** (tick 180) : 10 Bandits
   - HP : 80 chaque
   - Speed : 2.5
   - Bounty : 5$ × 10 = 50$

### Stratégie Recommandée
```
Budget initial : 300$
1. Archer (100$) au virage → reste 200$
2. Archer (100$) à l'entrée → reste 100$
3. Mitrailleuse (100$) au milieu → reste 0$

Après vague 1 : +45$ → upgrade ou nouvelle tour
Après vague 2 : +50$ → amélioration finale

Total disponible : 395$ (300 + 45 + 50)
Résultat : Victoire avec 13-15 vies restantes
```

### Carte ASCII
```
S = Start, E = Exit, # = Chemin, T = Emplacement tour

. . . . . . . . . . . .
. . . . . . . . . . . .
. . T . . . . . . T . .
. . . . . . . . . . . .
. . . . . . T . . . . .
. . . . . . . . . . . .
S # # # # # # T . . . .
. . . . . . # . . . . .
. . . . . . # . . . . .
. . . . . . # . . . . .
. . . . . . # . . . . .
. . . . . . # # # # # E
```

---

## 📌 Niveau 10 - Fin Early Game

### Configuration
- **Map** : 15×15
- **Budget** : 350$
- **Vies** : 12
- **Chemin** : En S (plus complexe)

### Vagues
1. **Vague 1** (tick 10) : 20 Gobelins
   - Total HP : 1000
   - Bounty : 60$

2. **Vague 2** (tick 170) : 15 Bandits
   - Total HP : 1200
   - Bounty : 75$

3. **Vague 3** (tick 310) : 10 Soldats
   - Total HP : 1200
   - Bounty : 70$

### Analyse DPS
- **HP total** : 3400
- **Temps disponible** : ~400 ticks = 80 secondes
- **DPS requis** : 42.5 DPS minimum

### Stratégie Optimale
```
Phase 1 (Budget 350$):
- 1 Archer Rank 2 (200$) au premier virage
  → DPS : 25 / 0.8s = 31.25 DPS
- 1 Mitrailleuse Rank 1 (120$) au deuxième virage
  → DPS : 8 / 0.3s = 26.7 DPS
- Reste : 30$

Total DPS initial : ~58 DPS ✅ (suffisant)

Phase 2 (Après vague 1 : +60$):
- Upgrade Mitrailleuse → Rank 2 (120$)
  → Nouveau DPS : 14 / 0.25s = 56 DPS
- Budget restant : -30$ (sera comblé par vague 2)

Phase 3 (Après vague 2 : +75$):
- 1 Canon Rank 1 (150$) sur ligne droite
  → DPS AOE : 25 / 2.0s = 12.5 DPS

DPS final : ~100 DPS
Résultat : Victoire avec 10-12 vies
```

### Carte ASCII (15×15)
```
. . . . . . . . . . . . . . .
. . . . . . . . . . . . . . .
S # # # # # # # T . . . . . .
. . . . . . . # . . . . . . .
. . . . . . . # . . . . . . .
. . T . . . . # # # # # # # .
. . . . . . . . . . . . . # .
. . . . . . . . . . . . . # .
. . . . . . . . . . . . . # .
. # # # # # # # # # # # # # .
. # . . . . . . . . . . . . .
. # . . T . . . . . . . . . .
. # . . . . . . . . . . . . .
. # . . . . . . . . . . . . .
. # # # # # # # # # # # # # E
```

---

## 📌 Niveau 20 - Défi Mid-Late Game

### Configuration
- **Map** : 22×22
- **Budget** : 600$
- **Vies** : 10 (⚠️ moins de marge d'erreur)
- **Chemin** : Zigzag complexe

### Vagues
1. **Vague 1** (tick 10) : 30 Soldats (120 HP chacun)
   - Total HP : 3600
   - Bounty : 210$

2. **Vague 2** (tick 240) : 25 Orcs (200 HP chacun)
   - Total HP : 5000
   - Bounty : 250$

3. **Vague 3** (tick 440) : 20 Chevaliers (350 HP chacun)
   - Total HP : 7000
   - Bounty : 300$

4. **Vague 4** (tick 610) : 15 Cavaliers (100 HP, speed 3.5)
   - Total HP : 1500
   - Bounty : 135$

### Analyse
- **HP total** : 17,100
- **Temps** : ~700 ticks = 140 secondes
- **DPS requis** : 122 DPS minimum
- **Défi** : Vague 4 = rushers rapides !

### Stratégie Avancée
```
Phase 1 (Budget 600$):
- 1 Sniper Rank 2 (360$) en début de chemin
  → DPS : 85 / 2.2s = 38.6 DPS
- 1 Canon Rank 2 (300$) au premier virage
  → DPS AOE : 40 / 1.8s = 22.2 DPS
- Reste : -60$ (sera compensé)

DPS initial : ~61 DPS (insuffisant, mais c'est normal)

Phase 2 (Après vague 1 : +210$ → Total 150$):
- NE RIEN FAIRE, économiser pour vague 2

Phase 3 (Après vague 2 : +250$ → Total 400$):
- 1 Baliste Rank 2 (400$) anti-armor sur ligne droite
  → DPS : 100 / 2.0s = 50 DPS

DPS à la vague 3 : ~111 DPS

Phase 4 (Après vague 3 : +300$ → Total 300$):
- 1 Mitrailleuse Rank 3 (360$) pour les rushers
  → DPS : 22 / 0.2s = 110 DPS (critique pour vague 4!)
- On est à -60$, mais vague 3 déjà passée

DPS final : ~220 DPS
Résultat : Victoire avec 8-10 vies (serré!)
```

### Points Clés
- ⚠️ **Ne pas gaspiller le budget initial**
- 💡 **Économiser entre les vagues**
- 🎯 **Anticiper la vague 4 (rushers)**
- 🔥 **Placement stratégique crucial**

---

## 📌 Niveau 30 - Boss Final

### Configuration
- **Map** : 30×30 (immense!)
- **Budget** : 1400$
- **Vies** : 8 (très peu de marge)
- **Chemin** : Très long et complexe

### Vagues
1. **35 Golems** (600 HP) = 21,000 HP
2. **30 Trolls** (800 HP) = 24,000 HP
3. **25 Fantômes** (250 HP, speed 3.0) = 6,250 HP
4. **20 Géants** (1200 HP) = 24,000 HP
5. **15 Dragons** (1500 HP) = 22,500 HP

### Statistiques Folles
- **HP total** : 97,750 HP 🔥
- **Temps** : ~1400 ticks = 280 secondes
- **DPS requis** : 349 DPS minimum ⚡
- **Budget total** : ~2900$ (1400 + ~1500 bounty)

### Stratégie Experte
```
Phase Initiale (1400$):
- 2 × Catapulte Rank 3 (1500$) aux virages principaux
  → DPS combiné : 2 × (220 / 2.5s) = 176 DPS
- On est à -100$, on attend bounty

Après Vague 1 (+875$, total 775$):
- 1 × Tesla Rank 3 (660$)
  → DPS chaîne : 95 / 1.4s = 67.8 DPS
- Reste : 115$

Après Vague 2 (+1050$, total 1165$):
- 1 × Baliste Rank 3 (600$)
- 1 × Sniper Rank 3 (540$)
- → DPS combiné : +122 DPS
- Reste : 25$

Après Vague 3 (+500$, total 525$):
- 1 × Lance-Flammes Rank 3 (540$)
- → DPS cone : 100 DPS
- Reste : -15$

Après Vague 4 (+1000$):
- 2 × Mage de Glace Rank 3 (840$) pour ralentir dragons
- 1 × Archer Rank 3 (300$) finisher

DPS FINAL : ~565 DPS
Résultat : Victoire avec 6-8 vies (très serré!)
```

### Conseils Critiques
1. **Prioriser les Catapultes** (AOE massif)
2. **Utiliser Tesla pour chaînes** (efficace sur groupes)
3. **Ralentir les Dragons** (sinon ils passent trop vite)
4. **Placer les tours sur TOUS les virages**
5. **Ne JAMAIS laisser 2 vagues se superposer**

---

## 🎓 Leçons d'Équilibrage

### Niveau 1 vs Niveau 30
| Aspect | Niveau 1 | Niveau 30 |
|--------|----------|-----------|
| HP Total | 1,050 | 97,750 |
| Budget Total | 395$ | ~2,900$ |
| DPS Requis | 13 DPS | 349 DPS |
| Tours Nécessaires | 2-3 | 8-10 |
| Durée | ~90s | ~280s |
| Difficulté | ⭐ | ⭐⭐⭐⭐⭐ |

### Progression Linéaire ?
Non ! La difficulté augmente **exponentiellement** :
- Niveau 1-10 : +20% par niveau
- Niveau 11-20 : +30% par niveau
- Niveau 21-30 : +40% par niveau

C'est voulu pour garder le challenge ! 🎯
