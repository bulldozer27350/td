# 🎮 Tower Defense - Données de Jeu Générées

## 📦 Contenu

Ce package contient **65 fichiers JSON** pour votre Tower Defense :
- **10 tours** avec 3 rangs chacune
- **15 types d'ennemis** avec progression de difficulté
- **30 niveaux** équilibrés avec courbe de difficulté progressive

## 🎯 Principes d'Équilibrage

### Économie
- **Budget initial** : 300-1500$ selon le niveau
- **Bounty** : 3-70$ par ennemi selon la difficulté
- **Principe** : Un joueur moyen peut réussir sans erreur grossière
- **Marge d'erreur** : ~20% du budget peut être "gaspillé"

### Durée
- **Maximum** : ~5 minutes par niveau
- **Tick rate** : 200ms (5 ticks/seconde)
- **Total estimé** : 600-1200 ticks par niveau

## 🗼 Tours (10 types)

### Tours de Base (Early Game)
1. **Archer** (100$) : Tour polyvalente, bon ratio coût/efficacité
2. **Mitrailleuse** (120$) : Cadence rapide, faibles dégâts individuels
3. **Canon** (150$) : Dégâts AOE modérés

### Tours Spécialisées (Mid Game)
4. **Sniper** (180$) : Longue portée, gros dégâts, lent
5. **Mage de Glace** (140$) : Ralentit les ennemis
6. **Tour de Poison** (160$) : Dégâts sur la durée

### Tours Avancées (Late Game)
7. **Baliste** (200$) : Anti-armor, perce les défenses
8. **Lance-Flammes** (180$) : Cône frontal, multi-cibles
9. **Catapulte** (250$) : Énormes dégâts AOE
10. **Tesla** (220$) : Chaîne d'éclairs entre ennemis

### Progression des Rangs
- **Rank 1** : Coût de base, stats de base
- **Rank 2** : Coût ×2, stats +60-70%
- **Rank 3** : Coût ×3, stats +100-110%

## 👾 Ennemis (15 types)

### Early Game (Niveaux 1-10)
- **Goblin** : 50 HP, 2.0 speed, 3$ - Ennemi de base
- **Bandit** : 80 HP, 2.5 speed, 5$ - Plus rapide
- **Soldat** : 120 HP, 2.0 speed, 7$ - Plus résistant

### Mid Game - Tanks (Niveaux 11-20)
- **Orc** : 200 HP, 1.5 speed, 10$
- **Chevalier** : 350 HP, 1.2 speed, 15$
- **Golem** : 600 HP, 1.0 speed, 25$

### Mid Game - Rushers (Niveaux 11-20)
- **Loup** : 60 HP, 4.0 speed, 6$ - Très rapide !
- **Cavalier** : 100 HP, 3.5 speed, 9$
- **Démon Rapide** : 150 HP, 5.0 speed, 12$ - Rush extrême

### Late Game (Niveaux 21-30)
- **Troll** : 800 HP, 1.5 speed, 35$
- **Géant** : 1200 HP, 1.0 speed, 50$
- **Dragon** : 1500 HP, 2.0 speed, 70$
- **Fantôme** : 250 HP, 3.0 speed, 20$ - Rapide et résistant
- **Élémentaire** : 400 HP, 2.5 speed, 30$
- **Hydre** : 1000 HP, 1.8 speed, 60$

## 📊 Progression des 30 Niveaux

### Levels 1-5 : TUTORIAL
- **Map** : 12×12
- **Budget** : 300$
- **Vies** : 15
- **Ennemis** : Goblin, Bandit (50-80 HP)
- **Tours** : Archer, Mitrailleuse (Rank 1)
- **Vagues** : 2 vagues de 15-10 ennemis
- **Objectif** : Apprendre les mécaniques de base

### Levels 6-10 : EARLY GAME
- **Map** : 15×15
- **Budget** : 350$
- **Vies** : 12
- **Ennemis** : + Soldat, Loup (jusqu'à 120 HP)
- **Tours** : + Canon (Ranks 1-2)
- **Vagues** : 3 vagues de 20-15-10 ennemis
- **Objectif** : Introduction des ennemis rapides

### Levels 11-15 : MID GAME
- **Map** : 18×18
- **Budget** : 450$
- **Vies** : 10
- **Ennemis** : + Orc, Chevalier (jusqu'à 350 HP)
- **Tours** : + Sniper, Mage de Glace (Rank 2)
- **Vagues** : 3 vagues de 25-20-15 ennemis
- **Objectif** : Tanks arrivent, nécessite stratégie

### Levels 16-20 : MID-LATE GAME
- **Map** : 22×22
- **Budget** : 600$
- **Vies** : 10
- **Ennemis** : + Cavalier, Golem (jusqu'à 600 HP)
- **Tours** : + Poison, Baliste (Rank 3)
- **Vagues** : 4 vagues de 30-25-20-15 ennemis
- **Objectif** : Chemins complexes, choix stratégiques

### Levels 21-25 : LATE GAME
- **Map** : 26×26
- **Budget** : 800$
- **Vies** : 8
- **Ennemis** : + Troll, Fantôme, Géant (jusqu'à 1200 HP)
- **Tours** : + Lance-Flammes (Rank 3)
- **Vagues** : 4 vagues de 35-30-25-20 ennemis
- **Objectif** : Haute difficulté, optimisation requise

### Levels 26-30 : END GAME
- **Map** : 30×30
- **Budget** : 1000-1400$ (progression)
- **Vies** : 8
- **Ennemis** : Dragon, Hydre, Élémentaire (jusqu'à 1500 HP)
- **Tours** : Toutes disponibles (Rank 3)
- **Vagues** : 5 vagues de 40-35-30-25-20 ennemis
- **Objectif** : Défi ultime, maîtrise complète

## 🎮 Exemples de Stratégies par Niveau

### Niveau 3 (Tutorial)
- **Budget** : 300$
- **Ennemis** : 25 gobelins/bandits (50-80 HP)
- **Stratégie recommandée** :
  - 2 Archers (200$) sur le virage
  - 1 Mitrailleuse (100$) à l'entrée
  - Total : 300$ (budget parfait)

### Niveau 15 (Mid Game)
- **Budget** : 450$ + bounty (~300$) = ~750$
- **Ennemis** : 60 ennemis (80-350 HP)
- **Stratégie recommandée** :
  - 2 Snipers Rank 2 (720$) aux points clés
  - 1 Canon Rank 1 (150$) pour AOE
  - Upgrade progressif avec le bounty

### Niveau 30 (End Game)
- **Budget** : 1400$ + bounty (~1500$) = ~2900$
- **Ennemis** : 150 ennemis (400-1500 HP)
- **Stratégie recommandée** :
  - 2 Catapultes Rank 3 (1500$) pour boss
  - 3 Tesla Rank 3 (1980$) pour chaînes
  - 2 Mages de Glace Rank 2 (560$) pour ralentir
  - Total : ~4000$ (optimisation nécessaire)

## ⚠️ Points d'Attention

### Équilibrage Testé
Les niveaux ont été calculés avec ces formules :
```
DPS_requis = Total_HP_ennemis / Temps_disponible
Budget_total = Starting_Money + (Enemy_Count × Bounty × 0.6)
```

### Ajustements Possibles
Si vous trouvez un niveau trop facile/difficile :
1. **Trop facile** : Réduire `startingMoney` de 10-20%
2. **Trop difficile** : Augmenter `startingMoney` ou réduire `count` des vagues
3. **Trop court** : Augmenter `spawnInterval` ou `count`
4. **Trop long** : Réduire `count` des dernières vagues

### Mécaniques Futures
Ces données sont prêtes pour l'ajout de :
- Ennemis volants (ajouter un champ `flying: true`)
- Boss (utiliser `count: 1` avec HP très élevés)
- Chemins multiples (ajouter plusieurs objets dans `paths`)
- Upgrades permanents (système déjà en place dans votre code)

## 📁 Structure des Fichiers

```
game_data/
├── towers/          (10 fichiers)
│   ├── archer.json
│   ├── canon.json
│   ├── sniper.json
│   └── ...
├── enemies/         (15 fichiers)
│   ├── goblin.json
│   ├── bandit.json
│   ├── dragon.json
│   └── ...
└── levels/          (30 fichiers)
    ├── niveau_1.json
    ├── niveau_2.json
    ├── ...
    └── niveau_30.json
```

## 🚀 Utilisation

1. Copiez les dossiers `towers/`, `enemies/`, `levels/` dans votre backend
2. Configurez votre API pour servir ces fichiers
3. Testez les niveaux 1-5 d'abord (tutorial)
4. Ajustez si nécessaire selon vos retours

## 📈 Statistiques

- **Total ennemis tués** : ~2500 (tous niveaux confondus)
- **HP total** : ~500,000 HP à détruire
- **Temps de jeu estimé** : 2-3 heures pour finir les 30 niveaux
- **Difficulté** : Progressive et équitable

Bon jeu ! 🎯
