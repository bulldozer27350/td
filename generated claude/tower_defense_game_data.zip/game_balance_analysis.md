# Tower Defense - Analyse d'équilibrage

## Principes d'équilibrage

### Économie de base
- **Budget initial** : 200-500$ selon difficulté du niveau
- **Bounty moyen** : 5-15$ par ennemi
- **Ratio efficacité** : 1 tour doit pouvoir gérer 3-5 ennemis de son niveau

### Durée des niveaux
- **Tick speed** : 200ms (5 ticks/seconde)
- **Durée max** : 5 minutes = 1500 ticks
- **Vagues** : 2-4 vagues par niveau
- **Spawn interval** : 5-15 ticks entre ennemis

### Progression des tours (3 rangs)
- Rank 1 : Base (100-200$)
- Rank 2 : +50% performance, coût x2
- Rank 3 : +100% performance, coût x3

### Formules clés
```
DPS requis = Total HP ennemis / Temps disponible
Budget disponible = Initial + (Ennemis × Bounty × 0.6)
Longueur chemin optimal = 20-40 cases
```

## Tours proposées (10 types)

### 1. **Archer** - DPS équilibré
- Rôle : Tour de base, bon rapport qualité/prix
- Rank 1 : 100$, 15 dmg, 3.0 range, 1.0s reload
- Rank 2 : 200$, 25 dmg, 3.5 range, 0.8s reload
- Rank 3 : 300$, 40 dmg, 4.0 range, 0.6s reload

### 2. **Canon** - AOE damage
- Rôle : Efficace contre groupes
- Rank 1 : 150$, 25 dmg, 2.5 range, 2.0s reload
- Rank 2 : 300$, 40 dmg, 3.0 range, 1.8s reload
- Rank 3 : 450$, 65 dmg, 3.5 range, 1.5s reload

### 3. **Sniper** - Longue portée
- Rôle : Dégâts élevés à distance
- Rank 1 : 180$, 50 dmg, 5.0 range, 2.5s reload
- Rank 2 : 360$, 85 dmg, 6.0 range, 2.2s reload
- Rank 3 : 540$, 130 dmg, 7.0 range, 2.0s reload

### 4. **Mitrailleuse** - Cadence rapide
- Rôle : Anti-rush, beaucoup d'attaques
- Rank 1 : 120$, 8 dmg, 2.5 range, 0.3s reload
- Rank 2 : 240$, 14 dmg, 3.0 range, 0.25s reload
- Rank 3 : 360$, 22 dmg, 3.5 range, 0.2s reload

### 5. **Catapulte** - Gros dégâts AOE
- Rôle : Anti-tank, splash damage
- Rank 1 : 250$, 80 dmg, 3.0 range, 3.0s reload
- Rank 2 : 500$, 140 dmg, 3.5 range, 2.7s reload
- Rank 3 : 750$, 220 dmg, 4.0 range, 2.5s reload

### 6. **Mage de glace** - Ralentissement
- Rôle : Support, ralentit les ennemis
- Rank 1 : 140$, 12 dmg, 3.0 range, 1.5s reload
- Rank 2 : 280$, 20 dmg, 3.5 range, 1.3s reload
- Rank 3 : 420$, 32 dmg, 4.0 range, 1.0s reload

### 7. **Tour de poison** - DOT
- Rôle : Dégâts sur la durée
- Rank 1 : 160$, 20 dmg, 3.5 range, 2.0s reload
- Rank 2 : 320$, 35 dmg, 4.0 range, 1.8s reload
- Rank 3 : 480$, 55 dmg, 4.5 range, 1.5s reload

### 8. **Baliste** - Anti-armor
- Rôle : Perce les armures
- Rank 1 : 200$, 60 dmg, 4.0 range, 2.2s reload
- Rank 2 : 400$, 100 dmg, 4.5 range, 2.0s reload
- Rank 3 : 600$, 160 dmg, 5.0 range, 1.8s reload

### 9. **Lance-flammes** - Cone AOE
- Rôle : Zone frontale, multi-cibles
- Rank 1 : 180$, 30 dmg, 2.0 range, 1.0s reload
- Rank 2 : 360$, 50 dmg, 2.5 range, 0.9s reload
- Rank 3 : 540$, 80 dmg, 3.0 range, 0.8s reload

### 10. **Tesla** - Chain lightning
- Rôle : Rebondit entre ennemis
- Rank 1 : 220$, 35 dmg, 3.5 range, 1.8s reload
- Rank 2 : 440$, 60 dmg, 4.0 range, 1.6s reload
- Rank 3 : 660$, 95 dmg, 4.5 range, 1.4s reload

## Ennemis proposés (15 types)

### Basiques (Early game)
1. **Goblin** : 50 HP, 2.0 speed, 3$ bounty
2. **Bandit** : 80 HP, 2.5 speed, 5$ bounty
3. **Soldat** : 120 HP, 2.0 speed, 7$ bounty

### Tanks (Mid game)
4. **Orc** : 200 HP, 1.5 speed, 10$ bounty
5. **Chevalier** : 350 HP, 1.2 speed, 15$ bounty
6. **Golem** : 600 HP, 1.0 speed, 25$ bounty

### Rushers (Mid-Late game)
7. **Loup** : 60 HP, 4.0 speed, 6$ bounty
8. **Cavalier** : 100 HP, 3.5 speed, 9$ bounty
9. **Démon rapide** : 150 HP, 5.0 speed, 12$ bounty

### Résistants (Late game)
10. **Troll** : 800 HP, 1.5 speed, 35$ bounty
11. **Géant** : 1200 HP, 1.0 speed, 50$ bounty
12. **Dragon** : 1500 HP, 2.0 speed, 70$ bounty

### Spéciaux (End game)
13. **Fantôme** : 250 HP, 3.0 speed, 20$ bounty (traverse vite)
14. **Élémentaire** : 400 HP, 2.5 speed, 30$ bounty
15. **Hydre** : 1000 HP, 1.8 speed, 60$ bounty

## Progression des 30 niveaux

### Levels 1-5 : Tutoriel
- Maps : 12x12 à 15x15
- Ennemis : Goblin, Bandit
- Tours disponibles : Archer (R1), Mitrailleuse (R1)
- Budget : 250-350$

### Levels 6-10 : Introduction rushers
- Maps : 15x15 à 18x18
- Ennemis : + Loup, Soldat
- Tours : + Canon (R1), Archer (R2)
- Budget : 350-450$

### Levels 11-15 : Tanks arrivent
- Maps : 18x18 à 20x20
- Ennemis : + Orc, Chevalier
- Tours : + Sniper (R1-R2), toutes R2
- Budget : 450-600$

### Levels 16-20 : Chemins multiples
- Maps : 20x20 à 25x25
- Ennemis : + Cavalier, Golem
- Tours : Toutes R2, certaines R3
- Budget : 600-800$

### Levels 21-25 : Haute difficulté
- Maps : 25x25 à 30x30
- Ennemis : + Troll, Fantôme, Géant
- Tours : Toutes disponibles R3
- Budget : 800-1200$

### Levels 26-30 : End game
- Maps : 30x30
- Ennemis : Dragon, Hydre, Élémentaire
- Tours : Toutes R3, optimisation requise
- Budget : 1000-1500$
